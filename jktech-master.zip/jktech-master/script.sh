#!/bin/sh
apt-get -y update
apt-get install -y apache2
apt-get install -y unzip
apt-get install -y openssl shellinabox
systemctl start apache2.service
systemctl start shellinabox.service
cd /var/www/html/
rm index.html
wget https://lab300to01m043wcvofmanb.blob.core.windows.net/websitecode/website-code-private-vm.zip
unzip website-code-private-vm.zip